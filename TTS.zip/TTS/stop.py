from modules.controller import Controller

control = Controller(23, 18)
control.stop()
control.cleanup()
